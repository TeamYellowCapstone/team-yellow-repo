<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    require "templates/navigation.php";
    ?>
    <center><h1><u>Contact Us</u></h1></center>

    <h2>Adress</h2>
    <ul>
        <li>550 E Spring St, Columbus, OH 43215</li>
    </ul>


    <h2>Phone</h2>
    <ul>
        <li>614-555-0110</li>
    </ul>

    <h2>Email</h2>
    <ul>
        <li><a href="mailto:mheywood@cscc.edu">mheywood@cscc.edu</a></li>
    </ul>

</body>
</html>